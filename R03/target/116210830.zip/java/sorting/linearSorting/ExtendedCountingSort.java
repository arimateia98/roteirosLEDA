package sorting.linearSorting;

import sorting.AbstractSorting;

/**
 * Classe que implementa do Counting Sort vista em sala. Desta vez este
 * algoritmo deve satisfazer os seguitnes requisitos: - Alocar o tamanho minimo
 * possivel para o array de contadores (C) - Ser capaz de ordenar arrays
 * contendo numeros negativos
 */
public class ExtendedCountingSort extends AbstractSorting<Integer> {

	@Override
    public void sort(Integer[] array, int leftIndex, int rightIndex) {
       if (leftIndex <= rightIndex && leftIndex >= 0 && rightIndex < array.length && array.length > 1){
            int minimo = array[leftIndex];
            int maximo = array[leftIndex];
            for(int i = leftIndex; i <= rightIndex; i++){
                if (array[i].compareTo(maximo) > 0){
                    maximo = array[i];
                }
                if (array[i].compareTo(minimo) < 0){
                    minimo = array[i];
                }
            }
            int[] auxiliar = new int[maximo - minimo+1];
            for (int i = leftIndex; i <= rightIndex; i++){
                auxiliar[array[i] - minimo] ++;
            }
            
            for (int i = 1; i < auxiliar.length; i++){
            	auxiliar[i] = auxiliar[i] + auxiliar[i-1];
            }
            
            Integer[] auxiliarOrdenado = new Integer[array.length];
            for (int i = rightIndex; i >= leftIndex; i--){
            	auxiliar[array[i] - minimo] --;
            	auxiliarOrdenado[auxiliar[array[i] - minimo]] = array[i];
            }
            
            for(int i = leftIndex; i <= rightIndex; i++){
            	array[i] = auxiliarOrdenado[i];
            }
       }
	}

}

